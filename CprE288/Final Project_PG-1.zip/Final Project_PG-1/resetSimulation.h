/*
 * resetSimulation.h
 *
 *  Created on: Apr 30, 2020
 *      Author: Jacob Aspinall
 */

#ifndef RESETSIMULATION_H_
#define RESETSIMULATION_H_

void resetSimulationBoard();

#endif /* RESETSIMULATION_H_ */
