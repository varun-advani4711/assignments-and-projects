

/**
 * main.c
 */
#include "lcd.h"
#include "Timer.h"
#include "cyBot_Scan.h"
#include "cyBot_uart.h"
#include "resetSimulation.h"
#include "movement.h"
#include "open_interface.h"
#include <math.h>

typedef struct a{
    int startAngle;
    int endAngle;
}angle_t;
int main(void)
{
    timer_init();
    lcd_init();


    oi_t *sensor = oi_alloc();
    oi_init(sensor);
    cyBot_uart_init();
    cyBOT_init_Scan(0b0111);
//    cyBOT_SERVO_cal();

    right_calibration_value = 256375;
    left_calibration_value = 1251250;
    //Part 1
    //    	char str[] = "Got an ";
    //    	int i;
    //    	char ch = cyBot_getByte();
    //    	for(i = 0; i<strlen(str); i++){
    //    	    char temp = str[i];
    //    	    cyBot_sendByte(temp);
    //    	}
    //    	cyBot_sendByte(ch);
    //    	lcd_printf("%d", ch);



//
//    while(1){
//        char ch = cyBot_getByte();
//        cyBot_sendByte(ch);
//        if(ch == 119){
//            moveForward(sensor, 500);
//
//        }
//        else if(ch== 115){
//            moveBackward(sensor, 500);
//
//        }
//        else if(ch == 97){
//            turnLeft(sensor, 82);
//            moveForward(sensor, 500);
//
//        }
//        else if(ch == 100){
//            turnRight(sensor, 82);
//            moveForward(sensor, 500);
//
//        }
//    }



         int scanAngle = 180;
        char ch = cyBot_getByte();
    cyBOT_Scan_t x;
    cyBOT_Scan_t data[100];
    angle_t objects[10];
    int i;
    int j;
    char str[1000];
    if(ch == 'm'){

        char* init = "Angle\tDistance(IR in cm)\tDistance(Ping in cm)\n\r";
        int k;
        for(k = 0; k<strlen(init);k++){
            cyBot_sendByte(init[k]);
        }
        for(i = 0; i<= scanAngle; i+= 2){
            cyBOT_Scan(i, &x);

           lcd_printf("%d", (int) x.sound_dist);
           sprintf(str, "%d\t%d\t\t\t\t%d\n\r",i, x.IR_raw_val, (int)x.sound_dist);
           for(j = 0; j <strlen(str);j++){
               cyBot_sendByte(str[j]);
           }
           data[i].sound_dist = x.sound_dist;
           data[i].IR_raw_val = x.IR_raw_val;
        }
//        int f;
//
//           for(f = 0; f<90;f++){
//           int count = 0;
//           int index = 0;
//           //if(some condition to check if object found)
//           if(count == 0){
//               objects[index].startAngle = i;
//               count++;
//           }
//           else{
//               objects[index].endAngle = i + count;
//               count++;
//           }
//           //else if(some condition to check if sensor has moved away from object)
//           if(count >= 4){
//               objects[index].endAngle = i;
//               index++;
//               count = 0;
//           }
//           else if(count < 4 && count > 0){
//               count = 0;
//           }
//           int min = 0;
//           double side = data[objects[0].startAngle].sound_dist;
//           double hypo = -2*side*side*cos((objects[0].endAngle - objects[0].startAngle)*(3.14/180));
//           double current = sqrt(((side * side) * 2) + hypo);
//           int l;
//           for(l = 0; l<index;l++){
//               side = data[objects[i].startAngle].sound_dist;
//               hypo = -2*side*side*cos((objects[i].endAngle - objects[i].startAngle)*(3.14/180));
//               double wid = sqrt(((side * side) * 2) + hypo);
//               if(wid < current){
//                   min = l;
//                   current = wid;
//               }
//           }
//           lcd_printf("%d smallest object of width %d", min, current);
//           }

    }


    oi_free(sensor);
    return 0;
}
